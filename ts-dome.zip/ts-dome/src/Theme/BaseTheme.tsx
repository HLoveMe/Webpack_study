

class _BaseTheme<T>{}

export const  BaseTheme = new _BaseTheme<Object>();