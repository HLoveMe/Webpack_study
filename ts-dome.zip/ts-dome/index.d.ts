import * as React from "react";
import { Component } from "react";
import { ViewPropTypes } from "react-native";

declare class Button<ViewPropTypes,T> extends Component<ViewPropTypes,T>{}